# Test results (10 unseen seeds per scenario)

| Scenario | Controller | Avg delay (s/veh) | sd | Stops/veh | Side-origin delay | Improvement vs Webster | Paired t | Wins/10 |
|---|---|---|---|---|---|---|---|---|
| Off-peak (light, steady) | Webster fixed-time | 16.72 | 0.31 | 1.24 | 18.28 | - | - | - |
| Off-peak (light, steady) | GA-tuned fixed-time | 21.86 | 0.35 | 1.42 | 25.42 | -30.8 % | 33.28 | 0 |
| Off-peak (light, steady) | Fuzzy (hand-tuned) | 30.57 | 0.58 | 1.29 | 29.70 | -82.9 % | 107.47 | 0 |
| Off-peak (light, steady) | GA-tuned fuzzy (proposed) | 18.37 | 0.37 | 1.24 | 19.30 | -9.9 % | 11.60 | 0 |
| Moderate (steady) | Webster fixed-time | 21.44 | 0.48 | 1.47 | 28.96 | - | - | - |
| Moderate (steady) | GA-tuned fixed-time | 26.27 | 0.42 | 1.63 | 29.87 | -22.5 % | 24.60 | 0 |
| Moderate (steady) | Fuzzy (hand-tuned) | 32.94 | 0.53 | 1.60 | 30.89 | -53.6 % | 61.82 | 0 |
| Moderate (steady) | GA-tuned fuzzy (proposed) | 22.10 | 0.71 | 1.44 | 21.26 | -3.1 % | 2.15 | 3 |
| Peak (congested, steady) | Webster fixed-time | 42.43 | 1.14 | 1.57 | 46.73 | - | - | - |
| Peak (congested, steady) | GA-tuned fixed-time | 33.42 | 1.31 | 1.79 | 36.37 | +21.3 % | -37.19 | 10 |
| Peak (congested, steady) | Fuzzy (hand-tuned) | 54.18 | 2.23 | 1.81 | 48.65 | -27.7 % | 15.61 | 0 |
| Peak (congested, steady) | GA-tuned fuzzy (proposed) | 31.64 | 1.18 | 1.61 | 30.73 | +25.4 % | -31.08 | 10 |
| Peak build-up and decay (training) | Webster fixed-time | 38.74 | 2.55 | 1.64 | 45.97 | - | - | - |
| Peak build-up and decay (training) | GA-tuned fixed-time | 33.91 | 2.77 | 1.74 | 37.92 | +12.5 % | -7.06 | 10 |
| Peak build-up and decay (training) | Fuzzy (hand-tuned) | 52.79 | 3.83 | 1.76 | 47.39 | -36.3 % | 18.66 | 0 |
| Peak build-up and decay (training) | GA-tuned fuzzy (proposed) | 31.16 | 2.34 | 1.58 | 29.67 | +19.6 % | -12.22 | 10 |
| Tidal shift EB to WB | Webster fixed-time | 23.57 | 1.45 | 1.52 | 30.92 | - | - | - |
| Tidal shift EB to WB | GA-tuned fixed-time | 27.43 | 0.95 | 1.66 | 29.81 | -16.4 % | 21.51 | 0 |
| Tidal shift EB to WB | Fuzzy (hand-tuned) | 35.44 | 1.59 | 1.63 | 33.51 | -50.4 % | 25.47 | 0 |
| Tidal shift EB to WB | GA-tuned fuzzy (proposed) | 23.04 | 0.81 | 1.47 | 22.87 | +2.2 % | -1.65 | 6 |
| Side-street surge at J3 | Webster fixed-time | 31.39 | 4.90 | 1.53 | 48.10 | - | - | - |
| Side-street surge at J3 | GA-tuned fixed-time | 42.82 | 6.69 | 1.62 | 66.31 | -36.4 % | 17.49 | 0 |
| Side-street surge at J3 | Fuzzy (hand-tuned) | 37.09 | 1.51 | 1.63 | 32.59 | -18.2 % | 5.04 | 1 |
| Side-street surge at J3 | GA-tuned fuzzy (proposed) | 23.66 | 1.11 | 1.47 | 22.17 | +24.6 % | -5.57 | 10 |
